# Listas
lista_produtos = ["Café", "Chá", "Chocolate"]
lista_precos = [3, 3, 5]
lista_quant = [10, 25, 15]


# Função imprimir produtos
def imprimirProduto():
  escolherProduto = input("Escolha entre 1, 2 e 3 para visualizar algum produto: ")

  if escolherProduto == "1":
    print (lista_produtos[0],"pelo preço de", lista_precos[0], "reais. Contém", lista_quant[0], "unidades.");
  elif escolherProduto == "2":
    print (lista_produtos[1],"pelo preço de", lista_precos[1], "reais. Contém", lista_quant[1], "unidades.")
  elif escolherProduto == "3":
    print (lista_produtos[2],"pelo preço de", lista_precos[2], "reais. Contém", lista_quant[2], "unidades.")

# Função retirar produto
def retirarProduto():
  print ("1 -", lista_produtos[0],",", lista_precos[0],"reais,", lista_quant[0],"unidades", "\n", "2 -", lista_produtos[1],",", lista_precos[1],"reais,", lista_quant[1],"unidades", "\n", "3 -", lista_produtos[2],",", lista_precos[2],"reais,", lista_quant[2],"unidades", "\n")
  eliminarProduto = input ("Escolha o produto que deseja eliminar da lista: ")

  if eliminarProduto == "1":
    del(lista_produtos[0], lista_precos[0], lista_quant[0])
    print ("Produtos restantes: ", lista_produtos, "pelos preços de", lista_precos, "com as respectivas quantidades: ", lista_quant)
  elif eliminarProduto == "2":
    del(lista_produtos[1], lista_precos[1], lista_quant[1])
    print ("Produtos restantes: ", lista_produtos, "pelos preços de", lista_precos, "com as respectivas quantidades: ", lista_quant)
  elif eliminarProduto == "3":
    del(lista_produtos[2], lista_precos[2], lista_quant[2])
    print ("Produtos restantes: ", lista_produtos, "pelos preços de", lista_precos, "com as respectivas quantidades: ", lista_quant)  

# ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ # ~ #

# Programa Principal
while True:
  escolha = input('''
  Menu

  1- Mostrar produtos
  2 - Retirar algum produto da lista
  3 - Finalizar programa
  Escolha: ''')
  if escolha == "1":
    imprimirProduto()
  elif escolha == "2":
    retirarProduto()
  elif escolha == "3":
    break